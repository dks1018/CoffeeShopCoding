#ifndef __XSMTP_CONF_H
#define __XSMTP_CONF_H

// Mail Server configurations
#define PORT 25  // use port 25, need root privilege
#define MAX_CLIENTS 32
#define MAX_RCPT_USR 50
#define BUF_SIZE 1024

// User information saving configurations
const char data_dir[] = "/root/Documents/git/repos/xsmtp/data/";
const char userinfo[] = "userinfo";
const char userstat[] = "userstat";

extern int mail_stat;
extern int rcpt_user_num;
extern char from_user[64];
extern char rcpt_user[MAX_RCPT_USR][30];

#endif
