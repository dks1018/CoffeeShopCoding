#ifndef __XSMTP_H
#define __XSMTP_H

#include "common.h"
#include "module_mail.h"
#include "module_user.h"

#endif /* __XSMTP_H */

// Local Variables:
// mode: C++
// End:
