#include <iostream>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <stdlib.h>
using namespace std;

char displayArray [5][5];
char mineArray[5][5];
char playAgain[5][5];

int numMines;
int xPosNum;
int yPosNum;
int count = 0;

string mines;
string xPos;
string yPos;



int main(){
    printf("Hello World");

    return 0;
}