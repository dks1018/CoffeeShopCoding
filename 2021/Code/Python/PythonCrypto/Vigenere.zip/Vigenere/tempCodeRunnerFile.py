
MAX_KEY_LENGTH = 16 # Will not attempt keys longer than this.